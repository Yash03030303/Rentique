package com.capgemini.equipment_rental;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EquipmentRentalApplication {

	public static void main(String[] args) {
		SpringApplication.run(EquipmentRentalApplication.class, args);
	}

}
