package com.capgemini.equipment_rental;

import org.junit.jupiter.api.Test;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EquipmentRentalApplicationTests {

	@Test
	void contextLoads() {
	    // It's intentionally left empty because if the context fails to load
	}

}
